from telebot import TeleBot, types

# Botni token bilan boshlash
TOKEN = '8165837799:AAH5zXUjqu4AxXZIeqaEt-tWzsv9RigJAcU'  # O'zingizning bot tokeningizni kiriting
bot = TeleBot(TOKEN)

# Savatcha uchun ro'yxat
cart = []

# Start komandasini qo'shish
@bot.message_handler(commands=['start'])
def send_welcome(message):
    """Xush kelibsiz xabarini tugma variantlari bilan yuborish."""
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    buttons = [
        types.KeyboardButton("🍽Menyu"),
        types.KeyboardButton("🛒Mening buyurtmalarim"),
        types.KeyboardButton("🛍Savatcha"),
        types.KeyboardButton("📨 Xabar yuborish"),
        types.KeyboardButton("📲Aloqa"),
        types.KeyboardButton("⚙️Sozlamalar"),
        types.KeyboardButton("ℹ️Biz haqimizda")  # Yangi tugma qo'shildi
    ]
    markup.add(*buttons)
    bot.send_message(
        chat_id=message.chat.id,
        text="Tugmalardan birini tanlang:",
        reply_markup=markup
    )

# Menyu tugmasi bosilganda qo'shimcha tugmalarni ko'rsatish
@bot.message_handler(func=lambda message: message.text == "🍽Menyu")
def show_menu(message):
    """Menyu tugmasi bosilganda qo'shimcha tugmalarni ko'rsatish."""
    markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=2)
    buttons = [
        types.KeyboardButton("Setlar (8)"),
        types.KeyboardButton("Lavash (9)"),
        types.KeyboardButton("Shaurma (4)"),
        types.KeyboardButton("Burger (4)"),
        types.KeyboardButton("Hot-Dog (8)"),
        types.KeyboardButton("Ichimliklar (11)"),
        types.KeyboardButton("🔙 Orqaga")  # Orqaga qaytish tugmasi
    ]
    markup.add(*buttons)
    bot.send_message(
        chat_id=message.chat.id,
        text="Menyu:",
        reply_markup=markup
    )

# Har bir tugma bosilganda rasm va ma'lumot ko'rsatish
@bot.message_handler(func=lambda message: message.text in [
    "Setlar (8)", "Lavash (9)", "Shaurma (4)", "Burger (4)", "Hot-Dog (8)", "Ichimliklar (11)"
])
def show_item_details(message):
    """Tanlangan item uchun rasm va ma'lumot ko'rsatish."""
    item_details = {
        "Setlar (8)": {
            "image": "https://avatars.mds.yandex.net/i?id=eb9938122014992151c215af8ff3b898_l-3765082-images-thumbs&n=13",
            "description": "Setlar: Qarsildoq chipslar, yangi bodring va pomidorlar bilan lavashga o'ralgan yumshoq mol go'shti, bizning ta'mi o'tkir qayla bilan.\nNarxi: 26 000 so'm."
        },
        "Lavash (9)": {
            "image": "https://just-eat.by/image/data/shops/36716/139199.jpg",
            "description": "Lavash: Yangi sabzavotlar va maxsus sous bilan tayyorlangan lavash.\nNarxi: 25 000 so'm."
        },
        "Shaurma (4)": {
            "image": "https://avatars.mds.yandex.net/i?id=fffe4ec774303641bbf78f4c9ebc29c8_l-10075807-images-thumbs&n=13",
            "description": "Shaurma: Yengil va mazali shaurma, yangi sabzavotlar bilan.\nNarxi: 20 000 so'm."
        },
        "Burger (4)": {
            "image": "https://avatars.mds.yandex.net/i?id=13e971a69914eb21376306b83e034732_l-5228667-images-thumbs&n=13",
            "description": "Burger: Maxsus go'sht va sabzavotlar bilan tayyorlangan burger.\nNarxi: 22 000 so'm."
        },
        "Hot-Dog (8)": {
            "image": "https://avatars.mds.yandex.net/i?id=fcbe9a46671fdccea088b33a0a3f90f0_l-7552414-images-thumbs&n=13",
            "description": "Hot-Dog: Yengil va tez tayyorlanadigan hot-dog.\nNarxi: 15 000 so'm."
        },
        "Ichimliklar (11)": {
            "image": "https://avatars.mds.yandex.net/i?id=c452810687eb7aa112b80026ff84d971_l-4914134-images-thumbs&n=13",
            "description": "Ichimliklar: Turli xil ichimliklar, har qanday ta'mga mos keladi.\nNarxi: 5 000 so'm."
        }
    }
    
    details = item_details.get(message.text)
    
    if details:
        bot.send_photo(chat_id=message.chat.id, photo=details["image"])
        bot.send_message(chat_id=message.chat.id, text=details["description"])
        # Savatchaga qo'shish tugmasi
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(types.KeyboardButton("Savatchaga qo'shish"))
        bot.send_message(chat_id=message.chat.id, text="Savatchaga qo'shish uchun tugmani bosing:", reply_markup=markup)

# Savatchaga qo'shish tugmasi bosilganda
@bot.message_handler(func=lambda message: message.text == "Savatchaga qo'shish")
def add_to_cart(message):
    """Savatchaga qo'shish tugmasi bosilganda."""
    # Oldingi xabarni olish
    previous_message = message.reply_to_message
    if previous_message:
        cart.append(previous_message.text)  # Tanlangan item nomini savatchaga qo'shamiz
        bot.send_message(chat_id=message.chat.id, text="✅ Savatchaga saqlandi!")
    else:
        bot.send_message(chat_id=message.chat.id, text="❌ Tanlangan itemni qo'shish mumkin emas.")

# Savatcha tugmasi bosilganda
@bot.message_handler(func=lambda message: message.text == "🛍Savatcha")
def show_cart(message):
    """Savatchani ko'rsatish."""
    if cart:
        cart_items = "\n".join(cart)
        bot.send_message(chat_id=message.chat.id, text=f"Savatchangiz:\n{cart_items}")
    else:
        bot.send_message(chat_id=message.chat.id, text="Savatchangiz bo'sh.")

# Boshqa barcha xabarlar uchun handler
@bot.message_handler(func=lambda message: True)
def reply_to_button(message):
    """Tanlangan tugmaga qarab javob berish."""
    if message.text == "ℹ️Biz haqimizda":
        # Rasm URL manzilini kiriting
        photo_url = 'https://example.com/path/to/your/image.jpg'  # Rasm URL manzilini o'zgartiring
        bot.send_photo(chat_id=message.chat.id, photo=photo_url)
        bot.send_message(chat_id=message.chat.id, text=(
            "EVOS®\n\n"
            "Kompaniyamizning birinchi filiali 2006 yilda ochilgan bo'lib, shu kungacha muvaffaqiyatli faoliyat yuritib kelmoqdalar. "
            "15 yil davomida kompaniya avtobus bekatidagi kichik ovqatlanish joyidan zamonaviy, kengaytirilgan tarmoqqa aylandi, "
            "bugungi kunda O'zbekiston bo'ylab 60 dan ortiq restoranlarin, o'zining eng tezkor yetkazib berish xizmatini, "
            "zamonaviy IT-infratuzilmasini va 2000 dan ortiq xodimlarni o'z ichiga oladi."
        ))
    elif message.text == "🔙 Orqaga":
        send_welcome(message)  # Orqaga qaytish uchun asosiy menyuni ko'rsatish
    elif message.text == "📲Aloqa":
        # Aloqa ma'lumotlarini va rasmni yuborish
        contact_photo_url = 'https://example.com/path/to/contact/image.jpg'  # Rasm URL manzilini o'zgartiring
        bot.send_photo(chat_id=message.chat.id, photo=contact_photo_url)
        bot.send_message(chat_id=message.chat.id, text=(
            "Kontaktlar\n"
            "Call-центр\n\n"
            "+998 71-203-12-12\n"
            "+998 71-203-55-55\n\n"
            "Yetkazib berish telefon raqamlari:\n\n"
            "Toshkent\n"
            "+998 71-203-12-12\n"
            "Namangan\n"
            "+998 78-147-12-12\n"
            "Farg'ona\n"
            "+998 73-249-12-12\n"
            "Qo'qon\n"
            "+998 73-542-78-78\n"
            "Andijon\n"
            "+998 74-224-12-12\n"
            "Samarqand\n"
            "+998 78-129-16-16\n"
            "Qarshi\n"
            "+998 78-129-17-17"
        ))
    elif message.text == "⚙️Sozlamalar":
        # Sozlamalar ma'lumotlarini yuborish
        markup = types.ReplyKeyboardMarkup(resize_keyboard=True, row_width=1)
        buttons = [
            types.KeyboardButton("🇺🇿 Tilni o'zgartirish"),
            types.KeyboardButton("🗑 Malumotlarni tozalash"),
            types.KeyboardButton("🔙 Orqaga qaytish")
        ]
        markup.add(*buttons)
        bot.send_message(chat_id=message.chat.id, text="Sozlamalar:", reply_markup=markup)
    else:
        responses = {
            "🛒Mening buyurtmalarim": "Sizning buyurtmalaringiz:",
            "📨 Xabar yuborish": "Xabar yuborish uchun tayyorman.",
            "Salom": "Salom, yaxshimisiz?",
            "Xayr": "Xayr, yana ko'rishamiz!"
        }
        response = responses.get(message.text, "Men bu tugmani tushunmadim.")
        bot.send_message(chat_id=message.chat.id, text=response)

# Botni ishga tushirish
if __name__ == "__main__":
    bot.polling()
